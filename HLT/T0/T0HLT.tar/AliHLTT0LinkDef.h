// Auto generated file - do not edit
#if !defined(__CINT__) && !defined(__CLING__)
# error Not for compilation
#else 
#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class AliHLTT0RecoComponent+;
#pragma link C++ class AliHLTT0Agent+;

#endif // __CINT__
//
// EOF
//
